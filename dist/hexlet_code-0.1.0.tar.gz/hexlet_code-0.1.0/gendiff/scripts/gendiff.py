from gendiff.cli import parse_args
import sys

def main():
    parser = parse_args()
    args = parser.parse_args()
    
    print(f"Comparing {args.first_file} and {args.second_file}")
    print(f"Output format: {args.format}")

if __name__ == '__main__':
    main()