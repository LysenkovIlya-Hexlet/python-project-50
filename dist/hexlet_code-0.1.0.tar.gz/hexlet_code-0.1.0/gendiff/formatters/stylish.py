def format_stylish(diff, indent=0):
    lines = []
    spaces = ' ' * (indent * 4)
    
    for key, node in sorted(diff.items()):
        if node['type'] == 'nested':
            lines.append(f"{spaces}    {key}: {format_stylish(node['children'], indent + 1)}")
        elif node['type'] == 'added':
            lines.append(f"{spaces}  + {key}: {format_value(node['value'], indent)}")
        elif node['type'] == 'removed':
            lines.append(f"{spaces}  - {key}: {format_value(node['value'], indent)}")
        elif node['type'] == 'changed':
            lines.append(f"{spaces}  - {key}: {format_value(node['old'], indent)}")
            lines.append(f"{spaces}  + {key}: {format_value(node['new'], indent)}")
        else:
            lines.append(f"{spaces}    {key}: {format_value(node['value'], indent)}")
    
    result = "\n".join(lines)
    return "{\n" + result + "\n" + spaces + "}"

def format_value(value, indent):
    if isinstance(value, dict):
        nested_lines = []
        for k, v in value.items():
            nested_lines.append(f"{' ' * ((indent + 1) * 4)}{k}: {format_value(v, indent + 1)}")
        return "{\n" + "\n".join(nested_lines) + "\n" + (' ' * (indent * 4)) + "}"
    elif value is None:
        return 'null'
    else:
        return str(value)